
/* Name of the class has to be "main". */
class main
{
	public static void main (String[] args) throws java.lang.Exception
	{
		// your code goes here
	}
}
